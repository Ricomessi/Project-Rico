--CREATE PUBLIC LIBRARY TABLE

create database PublicLibrary
use PublicLibrary

--CREATE SCHEMA
create schema Member
create schema Book
create schema Librarian
create schema Loan
create schema back


Create Table PublicLibrary.Book.Supplier
(
SupplierOrderID char (5) not null,
SupplierID char (4) not null,
SupplierContact char (12) not null,
SupplierName varchar (8) not null
)

Create Table PublicLibrary.Book.Book
(
BookID char (4) not null,
BookName varchar (25) not null,
BookPublisher varchar (8) not null, 
BookType varchar (15) not null,
SupplierOrderID char (5) not null,
BookStock int not null,
)


Create Table PublicLibrary.Loan.Loan
(
LoanID char (4) not null,
LibrarianID char (5) not null,
MemberID char (4) not null,
)


Create Table PublicLibrary.Loan.LoanDetail
(
LoanID char (4) not null,
LoanDate date not null,
LibrarianID char (5) not null,
MemberID char (4) not null,
BookID char (4) not null,
ReturnDueDate date not null,
LoanQty smallint not null,
)


Create Table PublicLibrary.Loan.FinesRules
(
FinesRulesID char (5) not null,
LoanID char (4) not null,
FinesType varchar (7) not null,
Description varchar (10) not null,
FinesValue money not null,
)


Create Table PublicLibrary.Back.ReturnBook
(
ReturnID char (4) not null,
LoanID char (4) not null,
ReturnDate date not null,
LibrarianID char (5) not null,
MemberID char (4) not null,
BookID char (4) not null,
ReturnDueDate date not null,
)


Create Table PublicLibrary.Back.Fines
(
FinesID char (4) not null,
LoanID char (4) not null,
ReturnID char(4) not null,
Fines money not null,
)


Create Table PublicLibrary.Librarian.Librarian
(
LibrarianID char (5) not null,
LibrarianName varchar (10) not null,
LibrarianGender varchar (8) not null,
)

Create Table PublicLibrary.Member.Member
(
MemberID char (4) not null,
MemberName varchar (10) not null,
MemberAge Int not null,
MemberContact char (12) not null,
)


--ALTER CHECK CONSTRAINT (Primary Key)

ALTER TABLE Book.Supplier ADD CONSTRAINT PKSupplier PRIMARY KEY (SupplierOrderID)
ALTER TABLE Book.Book ADD CONSTRAINT PKBook PRIMARY KEY (BookID)
ALTER TABLE Loan.Loan ADD CONSTRAINT PKLoan PRIMARY KEY (LoanID)
ALTER TABLE Back.ReturnBook ADD CONSTRAINT PKReturn PRIMARY KEY (ReturnID)
ALTER TABLE Back.Fines ADD CONSTRAINT PKFines PRIMARY KEY (FinesID)
ALTER TABLE Member.Member ADD CONSTRAINT PKMember PRIMARY KEY (MemberID)
ALTER TABLE Librarian.Librarian ADD CONSTRAINT PKLibrarian PRIMARY KEY (LibrarianID)
ALTER TABLE Loan.FinesRules ADD CONSTRAINT PKFinesRules PRIMARY KEY (FinesRulesID)

--ALTER CHECK CONSTRAINT (Foreign Key)

ALTER TABLE Book.Book ADD CONSTRAINT FKSupplierBook FOREIGN KEY (SupplierOrderID) REFERENCES Book.Supplier (SupplierOrderID)
ALTER TABLE Loan.Loan ADD CONSTRAINT FKLibrarianBook FOREIGN KEY (LibrarianID) REFERENCES Librarian.Librarian (LibrarianID)
ALTER TABLE Loan.Loan ADD CONSTRAINT FKMemberLoan FOREIGN KEY (MemberID) REFERENCES Member.Member (MemberID)
ALTER TABLE Loan.Loan ADD CONSTRAINT FKLoanReturnRules FOREIGN KEY (LoanID) REFERENCES Loan.Loan (LoanID)
ALTER TABLE Loan.LoanDetail ADD CONSTRAINT FKLoanDetail FOREIGN KEY (LoanID) REFERENCES Loan.Loan (LoanID)
ALTER TABLE Loan.LoanDetail ADD CONSTRAINT FKLibrarianDetail FOREIGN KEY (LibrarianID) REFERENCES Librarian.Librarian (LibrarianID)
ALTER TABLE Loan.LoanDetail ADD CONSTRAINT FKMemberDetail FOREIGN KEY (MemberID) REFERENCES Member.Member(MemberID)
ALTER TABLE Loan.LoanDetail ADD CONSTRAINT FKBookDetail FOREIGN KEY (BookID) REFERENCES Book.Book (BookID)
ALTER TABLE Back.ReturnBook ADD CONSTRAINT FKReturnLoan FOREIGN KEY (LoanID) REFERENCES Loan.Loan (LoanID)
ALTER TABLE Back.ReturnBook ADD CONSTRAINT FKReturnLibrarian FOREIGN KEY (LibrarianID) REFERENCES Librarian.Librarian (LibrarianID)
ALTER TABLE Back.ReturnBook ADD CONSTRAINT FKReturnMember FOREIGN KEY (MemberID) REFERENCES Member.Member (MemberID)
ALTER TABLE Back.ReturnBook ADD CONSTRAINT FKReturnBook FOREIGN KEY (BookID) REFERENCES Book.Book (BookID)
ALTER TABLE Back.Fines ADD CONSTRAINT FKFinesLoan FOREIGN KEY (LoanID) REFERENCES Loan.Loan (LoanID)
ALTER TABLE Back.Fines ADD CONSTRAINT FKFinesReturn FOREIGN KEY (ReturnID) REFERENCES Back.ReturnBook (ReturnID)


--ALTER CHECK CONSTRAINT (Supplier)

ALTER TABLE Book.Supplier ADD CONSTRAINT CheckSupplierOrderIDinSupplier CHECK (SupplierOrderID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')
ALTER TABLE Book.Supplier ADD CONSTRAINT CheckSupplierIDinSupplier CHECK (SupplierID LIKE '[A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (Book)

ALTER TABLE Book.Book ADD CONSTRAINT CheckBookIDinBook CHECK (BookID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Book.Book ADD CONSTRAINT CheckSupplierOrderIDinBook CHECK (SupplierOrderID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (Member)

ALTER TABLE Member.Member ADD CONSTRAINT CheckMemberIDinMember CHECK (MemberID LIKE '[A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (Librarian)

ALTER TABLE Librarian.Librarian ADD CONSTRAINT CheckLibrarianIDinLibrarian CHECK (LibrarianID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (Loan)

ALTER TABLE Loan.Loan ADD CONSTRAINT CheckLoanIDinLoan CHECK (LoanID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.Loan ADD CONSTRAINT CheckLibrarianIDinLoan CHECK (LibrarianID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.Loan ADD CONSTRAINT CheckMemberIDinLoan CHECK (MemberID LIKE '[A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (LoanDetail)

ALTER TABLE Loan.Loandetail ADD CONSTRAINT CheckLoanIDinLoanDetail CHECK (LoanID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.Loandetail ADD CONSTRAINT LibrarianIDinLoanDetail CHECK (LibrarianID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.Loandetail ADD CONSTRAINT MemberIDinLoanDetail CHECK (MemberID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.Loandetail ADD CONSTRAINT CheckBookIDinLoanDetail CHECK (BookID LIKE '[A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (FinesRules)

ALTER TABLE Loan.FinesRules ADD CONSTRAINT CheckFinesRulesIDinFinesRules CHECK (FinesRulesID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')
ALTER TABLE Loan.FinesRules ADD CONSTRAINT CheckLoanIDinFinesRules CHECK (LoanID LIKE '[A-Z][0-9][0-9][0-9]')


--ALTER CHECK CONSTRAINT (ReturnBook)

ALTER TABLE Back.ReturnBook ADD CONSTRAINT CheckReturnIDinLoanDetail CHECK (ReturnID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Back.ReturnBook ADD CONSTRAINT CheckLibrarianIdIDinLoanDetail CHECK (LibrarianID LIKE '[A-Z][A-Z][0-9][0-9][0-9]')
ALTER TABLE Back.ReturnBook ADD CONSTRAINT CheckMemberIDinLoanDetail CHECK (MemberID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Back.ReturnBook ADD CONSTRAINT CheckBookIDinLoanDetail CHECK (BookID LIKE '[A-Z][0-9][0-9][0-9]')

--ALTER CHECK CONSTRAINT (Fines)

ALTER TABLE Back.Fines ADD CONSTRAINT CheckFinesIDinFines CHECK (FinesID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Back.Fines ADD CONSTRAINT CheckLoanIDinFines CHECK (LoanID LIKE '[A-Z][0-9][0-9][0-9]')
ALTER TABLE Back.Fines ADD CONSTRAINT CheckReturnIDinFines CHECK (ReturnID LIKE '[A-Z][0-9][0-9][0-9]')

--INSERT
--INSERT INTO Member.Member 
VALUES
('M001', 'Ahmad', '17',	'081263725379'),
('M002', 'Zainul', '19'	,'089538316564'),
('M003', 'Mufid', '18', '081276865435'),
('M004', 'Dennis', '20', '081322334455'),
('M005', 'Salomo', '19', '081234567890')

 

INSERT INTO Loan.Loan
VALUES
('L001', 'LI001', 'M001'),
('L002', 'LI002', 'M002'),
('L003', 'LI003', 'M003'),
('L004', 'LI004', 'M004'),
('L005', 'LI005', 'M005')

Insert Into Loan.FinesRules
VALUES
('FR001', 'L001', 'Late', '1', '5,000.00'),
('FR002', 'L002', 'Late', '7', '40,000.00'),
('FR003', 'L003', 'Late', '30', '200,000.00'),
('FR004', 'L004', 'Ontime', '0', '0,0.0'),
('FR005', 'L005', 'Missing', 'Miss', '400,000.00')

INSERT INTO Back.ReturnBook
VALUES
('R001',	'L001',	'2022-12-30',	'LI001',	'M001',	'B001',	'2022-12-27'),
('R002',	'L002',	'2022-12-30',	'LI002',	'M002',	'B002',	'2022-12-30'),
('R003',	'L003',	'2022-12-25',	'LI003',	'M003',	'B003',	'2022-12-25'),
('R004',	'L004',	'2022-12-30',	'LI004',	'M004',	'B004',	'2022-12-30'),
('R005',	'L005',	'2022-01-10',	'LI005',	'M005',	'B005',	'2022-01-03')

INSERT INTO Back.Fines
VALUES
('F001',	'L001',	'R001',	'15,000.00'),
('F002',	'L002',	'R002',	'0,0.0'),
('F003',	'L003',	'R003',	'0,0.0'),
('F004',	'L004',	'R004',	'0,0.0'),
('F005',	'L005',	'R005',	'40,000.00')

INSERT INTO Librarian.Librarian
VALUES
('LI001', 'Jordan','Male'),
('LI002', 'Mori',	'Male'),
('LI003', 'Toka',	'Male'),
('LI004', 'Izra',	'Male'),
('LI005', 'Ervin', 'Male')

INSERT INTO Book.Supplier
VALUES
('SO001',	'S001',	'089521122334',	'Fayyaz'),
('SO002',	'S002',	'081233456678',	'Rajif'),
('SO003',	'S003',	'081388776655',	'Ragil'),
('SO004',	'S004',	'089554326543',	'Akmal'),
('SO005',	'S005',	'085213578899',	'Frendy')

INSERT INTO Loan.LoanDetail
VALUES
('L001', '2022-12-20', 'LI001',	'M001', 'B001', '2022-12-27', '1'),
('L002', '2022-12-21' ,'LI002', 'M002', 'B002', '2022-12-30','1'),
('L003', '2022-12-22', 'LI003',	'M003', 'B003', '2022-12-25', '2'),
('L004', '2022-12-23', 'LI004', 'M004', 'B004', '2022-12-30', '1'),
('L005', '2022-12-24', 'LI005', 'M005' ,'B005', '2023-01-03', '2')


INSERT INTO Book.Book
VALUES
('B001',	'Petualangan si Kancil',	'Charista',	'Fabel',	'SO001', '20'),
('B002',	'Biografi Yana', 'Bayu',	'Biograph',	'SO002', '15'),
('B003',	'Keong Emas',	'Clara',	'FairyTale',	'SO003', '12'),
('B004',	'Matematika Diskrit',	'Jason',	'CollegeBook',	'SO004', '9'),
('B005',	'Basic Programing',	'Fitri',	'CollegeBook',	'SO005', '5')