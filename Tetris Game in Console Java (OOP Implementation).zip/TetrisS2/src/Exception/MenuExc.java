package Exception;

class MenuExc {

}
