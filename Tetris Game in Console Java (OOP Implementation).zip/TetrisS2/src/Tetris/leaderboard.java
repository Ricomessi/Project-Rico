package Tetris;
import java.io.*;
import java.util.*;

public class leaderboard {
    public static void main(String[] args) {
        // Read history.txt file
        List<String> history = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("history.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                history.add(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create leaderboard array
        List<Player> players = new ArrayList<>();
        for (String line : history) {
            String[] tokens = line.split(",");
            String name = tokens[0];
            int score = Integer.parseInt(tokens[1]);
            Player player = findPlayer(players, name);
            if (player == null) {
                player = new Player(name, score);
                players.add(player);
            } else {
                player.addScore(score);
            }
        }

        // Select top 3 scores (excluding duplicates)
        Collections.sort(players, (a, b) -> Integer.compare(b.getTotalScore(), a.getTotalScore()));
        List<String> leaderboard = new ArrayList<>();
        Set<String> usedNames = new HashSet<>();
        for (Player player : players) {
            String name = player.getName();
            if (!usedNames.contains(name)) {
                leaderboard.add(name + ":" + player.getTotalScore());
                usedNames.add(name);
            }
            if (leaderboard.size() == 3) {
                break;
            }
        }

        // Write result to leaderboard.txt file
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("leaderboard.txt"))) {
        	for(int i = 0; i< leaderboard.size(); i++ ) {
        		
        	}
            for (String line : leaderboard) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Display leaderboard
//        for (String line : leaderboard) {
//            System.out.println(line);
//        }
    }

    private static Player findPlayer(List<Player> players, String name) {
        for (Player player : players) {
            if (player.getName().equals(name)) {
                return player;
            }
        }
        return null;
    }

    private static class Player {
        private final String name;
        private int totalScore;

        public Player(String name, int score) {
            this.name = name;
            this.totalScore = score;
        }

        public String getName() {
            return name;
        }

        public int getTotalScore() {
            return totalScore;
        }

        public void addScore(int score) {
            this.totalScore += score;
        }
    }
}