package Tetris;

import java.util.Random;

public class TheBlock {
	
    private int type;
    private int direction;
    private int[] numbers;
    private String[] pattern;
    

    private static final int[][] Block_O = {{0, 0, 0, 1, 1, 0, 1, 1}};
    private static final int[][] Block_I = {{0, 0, 0, 1, 0, 2, 0, 3}, {0, 0, 1, 0, 2, 0, 3, 0}};
    private static final int[][] Block_Z = {{0, 0, 0, 1, 1, 1, 1, 2}, {0, 1, 1, 0, 1, 1, 2, 0}};
    private static final int[][] Block_S = {{0, 1, 0, 2, 1, 0, 1, 1}, {1, 1, 2, 1, 0, 0, 1, 0}};
    private static final int[][] Block_J = {{0, 0, 1, 0, 1, 1, 1, 2}, {0, 1, 0, 0, 1, 0, 2, 0}, {1, 2, 0, 2, 0, 1, 0, 0}, {2, 0, 2, 1, 1, 1, 0, 1}};
    private static final int[][] Block_L = {{0, 2, 1, 0, 1, 1, 1, 2}, {2, 1, 0, 0, 1, 0, 2, 0}, {1, 0, 0, 2, 0, 1, 0, 0}, {0, 0, 2, 1, 1, 1, 0, 1}};
    private static final int[][] Block_T = {{0, 0, 0, 1, 0, 2, 1, 1}, {0, 1, 1, 1, 2, 1, 1, 0}, {1, 2, 1, 1, 1, 0, 0, 1}, {2, 0, 1, 0, 0, 0, 1, 1}};
    private static final int[][][] ALL_BLOCKS = {Block_O, Block_I, Block_Z, Block_S, Block_J, Block_L, Block_T};
    
    private TheBlock() {
    }
    public static TheBlock create() {

        TheBlock t = new TheBlock();

        Random r = new Random();
        t.type = 1;//r.nextInt(7);
        t.numbers = new int[4];
        t.pattern = new String[2];
        
      

        switch (t.type) {
	        case 0:
	            // type O
	            t.pattern[0] = (" * *  " );
	            t.pattern[1] = (" * *  ");
	            break;
	        case 1:
	            // type I
	            t.pattern[0] = "          ";
	            t.pattern[1] = (" * * * *  ");
	            break;
	        case 2:
	            // type Z
	            t.pattern[0] = (" * *    ");
	            t.pattern[1] = ("   * *  ");
	            break;
	        case 3:
	            // type S
	            t.pattern[0] = ("   * *  ");
	            t.pattern[1] = (" * *    ");
	            break;
	        case 4:
	            // type J
	            t.pattern[0] = (" *      ");
	            t.pattern[1] = (" * * *  ");
	            break;
	        case 5:
	            // type L
	            t.pattern[0] = ("     *  ");
	            t.pattern[1] = (" * * *  ");
	            break;
	        case 6:
	            // type T
	            t.pattern[0] = (" * * *  ");
	            t.pattern[1] = ("   *    ");
	            break;
	    }
        return t;
    }

    public void rotate() {
        direction++;
    }

    public void unrotate() {
        direction--;
    }

    public int[] getNumbers() {
        return numbers;
    }

    public String[] getPattern() {
        return pattern;
    }

    public int[] getCoordinates() {
        int[][] coordinates = ALL_BLOCKS[type];
        return coordinates[direction % coordinates.length];
    }
}