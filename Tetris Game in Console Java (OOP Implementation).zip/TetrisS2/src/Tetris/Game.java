package Tetris;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import GUtility.GameState;
import GUtility.gameU;

public class Game  {

    public static int score;
    protected static int highScore;
    private String Username;
    protected static int X;
	protected static int Y;
    protected static int[][] gamemap;
    private final int Height= 10;
    private final int Length= 10;
    private TheBlock hold;
    protected static ArrayList<TheBlock> blockQueue;
	Scanner scanner=new Scanner(System.in);

	public String getUname() {
		return Username;
	}

    private static final int UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3;

    public Game() {
    	score = 0;
    	System.out.println("Masukan Nama : ");
    	Username = scanner.nextLine();
    	GameState gameState = GameState.Playing;
        gamemap = new int[Height][Length];
        blockQueue = new ArrayList<>();
        gameU.cc();
        gameU.spawnLoc();
        gameU.randomGenerate();
        gameU.insShadow();
        displayUI();
    }



    private void displayUI() {
        printgamemap();
        System.out.println(" ===========================================");
        System.out.printf(" =============== Score :%d =========", score);
        System.out.println("\n ===========================================");
        System.out.println(" = DOWN [K] UP [I] RIGHT [L] LEFT [J]      =");
        System.out.println(" = ROTATE [W] HOLD [S] INSERT [Q] EXIT [E] =");
        processInput();
    }

    private void printgamemap() {
        System.out.print("\n +-");
        for (int i = 1; i <= Length; i++) {
            System.out.print("--");
        }
        System.out.println("+");

        for (int i = 0; i < Height; i++) {
            System.out.print(" | ");
            for (int j : gamemap[i]) {
                if (j == 0) {
                    System.out.print("  ");
                } else if (j == -11) {
                    System.out.print("* ");
                } else if (j < 0 && j > -11) {
                    System.out.print("x ");
                } else if (j > 0 && j < 11) {
                    System.out.print("* ");
                } else {
                    System.out.print("??");
                }
            }
            System.out.print("|");
            
            System.out.println();
        }

        System.out.print(" +-");
        for (int i = 1; i <= Length; i++) {
            System.out.print("--");
        }
        System.out.println("+");
    }

    

 // Tanda
    private void moveBlock(int direction) {
        if (validateMove(direction)) {
            
			gameU.remShadow();
            switch (direction) {
                case UP:
                    Y--;
                    break;
                case DOWN:
                    Y++;
                    break;
                case LEFT:
                    X--;
                    break;
                case RIGHT:
                    X++;
                    break;
            }
            gameU.insShadow();
            displayUI();
        } else {
            System.out.println("out of the box...");
        }
    }

    private void holdBlock() {
        gameU.remShadow();
        if (hold == null) {
            hold = blockQueue.remove(0);
            gameU.randomGenerate();
        } else {
            blockQueue.add(hold);
            hold = blockQueue.remove(0);
            // to rotate the list
            for (int i = 0; i < blockQueue.size() - 1; i++) {
                blockQueue.add(blockQueue.remove(0));
            }
        }
        gameU.spawnLoc();
        gameU.insShadow();
        displayUI();
    }

    private void rotateBlock() {
        if (validateRot()) {
            gameU.remShadow();
            blockQueue.get(0).rotate();
            gameU.insShadow();
            displayUI();
        } else {
            System.out.println("rotation out of the box...");
        }
    }

    private void insertCurrentBlock() {
        if (validateInsert()) {
            gameU.remShadow();
            gameU.iValue(blockQueue.remove(0), X, Y, false, 0);
            gameU.clearRow();
            gameU.spawnLoc();
            gameU.insShadow();
            gameU.randomGenerate();
            displayUI();
            score +=100;
        } else {
            System.out.println("overlapping...");
        }
    }

    private boolean validateMove(int direction) {
        for (int i = 0; i < 4; i++) {
            int by = blockQueue.get(0).getCoordinates()[2 * i] + Y;
            int bx = blockQueue.get(0).getCoordinates()[2 * i + 1] + X;

            switch (direction) {
                case UP:
                    if (by < 1) return false;
                    break;
                case DOWN:
                    if (by > gamemap.length - 2) return false;
                    break;
                case LEFT:
                    if (bx < 1) return false;
                    break;
                case RIGHT:
                    if (bx > gamemap[0].length - 2) return false;
                    break;
            }
        }
        return true;
    }

    private boolean validateRot() {
        blockQueue.get(0).rotate();
        for (int i = 0; i < 4; i++) {
            int by = blockQueue.get(0).getCoordinates()[2 * i] + Y;
            int bx = blockQueue.get(0).getCoordinates()[2 * i + 1] + X;

            if (by < 0 || by > gamemap.length - 1 || bx < 0 || bx > gamemap[0].length - 1) {
                blockQueue.get(0).unrotate();
                return false;
            }
        }
        blockQueue.get(0).unrotate();
        return true;
    }

    private boolean validateInsert() {
        for (int i = 0; i < 4; i++) {
            int by = blockQueue.get(0).getCoordinates()[2 * i] + Y;
            int bx = blockQueue.get(0).getCoordinates()[2 * i + 1] + X;

            if (gamemap[by][bx] != -11) {
                return false;
            }
        }
        return true;
    }
    
    private void processInput() {
        while (true) {
            try {
                if (scanner.hasNext()) {
                    String input = scanner.next().toLowerCase();
                    if (input.length() != 1) {
                        System.out.println("Invalid input. Please enter a single character.");
                        continue;
                    }
                    switch (input) {
                        case "w":
                            rotateBlock();
                            break;
                        case "s":
                            holdBlock();
                            break;
                        case "q":
                            insertCurrentBlock();
                            
                            break;
                        case "e":
                        	saveScore(Username,score);
                            System.exit(0);
                            break;
                        case "j":
                            moveBlock(LEFT);
                            break;
                        case "l":
                            moveBlock(RIGHT);
                            break;
                        case "i":
                            moveBlock(UP);
                            break;
                        case "k":
                            moveBlock(DOWN);
                            break;
                        default:
                            System.out.println("Invalid input. Please enter a valid character.");
                            break;
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid character.");
                scanner.next();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }




    public static String nama() {
        String name;
        Game game = new Game(); 
        name = game.getUname(); 
        return name;
    }

    public static  int FinalScore() {
    	int sc;
    	Game game = new Game();
    	sc = game.getScore();
    	return sc;
    	
    }
    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public static void saveScore(String username, int score) {
        try {
            FileWriter writer = new FileWriter("history.txt", true);
            writer.write(username + "," + score + "\n");
            writer.close();
            System.out.println("Score saved to leaderboard.");
        }
        catch (IOException e) {
            System.out.println("An error occurred while saving the score to the leaderboard: " + e.getMessage());
        }
    }
    
}

