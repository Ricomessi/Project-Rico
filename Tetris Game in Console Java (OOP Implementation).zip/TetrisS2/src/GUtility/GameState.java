package GUtility;


import Tetris.Game;

public enum GameState {
    Playing,
    GameOver;

	public static  void handleGameOver() {
    	
           System.out.println("Game over!");
        String name = Game.nama();
        int score = Game.FinalScore();
        Game.saveScore(name, score);
        System.out.println("Thanks for playing, " + name + "!");
        System.exit(0);
    }
}
