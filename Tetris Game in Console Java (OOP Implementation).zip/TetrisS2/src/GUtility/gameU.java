package GUtility;
import Tetris.Game;
import Tetris.TheBlock;

import java.io.IOException;
import java.util.ArrayList;

public class gameU extends Game{
	
	public static void cc() {
		System.out.println("Work");
        final String os = System.getProperty("os.name");

        try {
            if (os.contains("Windows")) {
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            } else {
                Runtime.getRuntime().exec("clear");	
            }
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();}}
	
	public static void spawnLoc() {
        X = 5;
        Y = 0;
    }

    public static void iValue(TheBlock block, int x, int y, boolean custom, int customValue) {
        for (int i = 0; i < 4; i++) {
            int by = block.getCoordinates()[2 * i] + y;
            int bx = block.getCoordinates()[2 * i + 1] + x;

            if (custom) {
                gamemap[by][bx] += customValue;
            } else {
                gamemap[by][bx] += block.getNumbers()[i] + 1;
            }
        }
    }

    public static void insShadow() {
        iValue(blockQueue.get(0), X, Y, true, -11);
    }

    public static void remShadow() {
        iValue(blockQueue.get(0), X, Y, true, +11);
    }


    public static void clearRow() {
    	GameState gameState = GameState.Playing;
    	ArrayList<Integer> rowsToClear = new ArrayList<>();

    	// Check if rows are clearable
    	for (int i = 1; i < gamemap.length; i++) {
    	    boolean isClearable = true;
    	    int sum = 0;
    	    for (int j = 0; j < gamemap[0].length; j++) {
    	        if (gamemap[i][j] < 1) {
    	            isClearable = false;
    	            break;
    	        }
    	        sum += gamemap[i][j];
    	    }
    	    if ((i == 1 || isClearable) && sum % 2 == 0) {
    	        rowsToClear.add(i);
    	    }
    	}
    	for (int j = 0; j < gamemap[0].length; j++) {
    	    boolean isFull = true;
    	    for (int i = 0; i < gamemap.length; i++) {
    	        if (gamemap[i][j] < 1) {
    	            isFull = false;
    	            break;
    	        }
    	    }
    	    if (isFull) {
    	    	gameState = GameState.GameOver;
    	        GameState.handleGameOver();
    	        break;
    	    }}
    	

    	// Clear rows and columns that are clearable
    	for (int i : rowsToClear) {
    	    for (int j = 0; j < gamemap[0].length; j++) {
    	        gamemap[i][j] = 0;
    	        Game.score += 10;
    	    }
    	}
        // Update score and check for new high score

    
    }

    public static void randomGenerate() {
        for (int i = blockQueue.size(); i < 3; i++) {
            blockQueue.add(TheBlock.create());
        }
    }


}
