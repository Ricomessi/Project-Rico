

import java.util.Scanner;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Tetris.*;
import GUtility.gameU;
public class Menu  {
		
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		int pilihan;
		System.out.println("===TETRIS GAME===");
		System.out.println("1. Play          ");
		System.out.println("2. leaderboard   ");
		System.out.println("3. Exit          ");
		System.out.print("Enter your choice: ");
        pilihan = sc.nextInt();
		do {
	            switch(pilihan) {
	            case 1:
	            	gameU.cc();
	            	new Game();
	            	break;
	            case 2:
	            	
	            	gameU.cc();
	            	  // Call leaderboard's main method
	                leaderboard.main(args);

	                // Read leaderboard.txt file
	                List<String> leaderboard = new ArrayList<>();
	                try (BufferedReader br = new BufferedReader(new FileReader("leaderboard.txt"))) {
	                    String line;
	                    while ((line = br.readLine()) != null) {
	                        leaderboard.add(line);
	                    }
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }

	                // Display leaderboard
	                int count = 0;
	                System.out.println("Top 3 leaderboard:");
	                for (String line : leaderboard) {
	                	if (count >= 3) break;
	                    System.out.println((count+1) +" . "+line );
	                    count++;
	                }
	            
	            	pilihan = 3;
	            	break;
	            case 3:
	            	break;
	            default:
	            	System.out.println("angka tidak ada di pilihan");
	            	pilihan = 3;
	            	break;
	            }
		} while (pilihan != 3);
		sc.close();
        System.exit(0);
	}
}
