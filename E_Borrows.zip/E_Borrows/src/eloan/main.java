/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eloan;

/**
 *
 * @author Hp
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        splash ss = new splash();
        ss.setVisible(true);
        // TODO code application logic here
    }
    
}
